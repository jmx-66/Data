#!/usr/bin/env python3
"""bootstrap.py — 工作守则建档与校验脚本。

由 skill「gongzuoshouze」的强制作业序列第 2 步调用。
职责：强制创建或校验三份核心文档，并输出可供 agent 判断的结构化报告。

安全边界：
- 仅在工作空间根目录内做文件读写；
- 绝不删除既有文档，缺文件时只从模板复制生成；
- 不联网、不读取工作空间以外的路径。

退出码：0 = 三文档就绪且当前进度为今日更新；1 = 需处理（有缺文件或进度过期）。
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

DOC_NAMES = ("实验目的.md", "实验架构.md", "当前进度.md")
TODAY = date.today()

# skill 目录：<安装位置>/gongzuoshouze/scripts/bootstrap.py
SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
TEMPLATE_DIR = SKILL_DIR / "assets" / "templates"
MARKER = "工作守则.md"

# 本 skill 唯一服务的工作空间。安装到用户级目录后，无法再靠相对路径推断，
# 因此显式声明，优先级最低（可被 --root 与 cwd 覆盖）。
DEFAULT_WORKSPACE = Path(r"C:\Users\DELL\Desktop\工作守则")

# 用于识别"今日已更新"的判定依据：文档中出现今日日期串
TODAY_STAMP = TODAY.isoformat()


def resolve_root(explicit: str | None) -> Path:
    """按优先级解析工作空间根目录：--root > 当前目录 > 声明的工作空间。"""
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    candidates.append(Path.cwd())
    candidates.append(DEFAULT_WORKSPACE)
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        if (resolved / MARKER).exists():
            return resolved
    return DEFAULT_WORKSPACE.resolve()


def progress_is_fresh(path: Path) -> bool:
    """判断当前进度.md 是否已在今日更新过。"""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return False
    if TODAY_STAMP in text:
        return True
    try:
        return date.fromtimestamp(path.stat().st_mtime) == TODAY
    except (OSError, ValueError):
        return False


def ensure_doc(root: Path, name: str, report: list[str]) -> bool:
    """确保单份文档存在，缺失则从模板复制。返回是否已就绪。"""
    target = root / "docs" / name
    if target.exists():
        report.append(f"[OK]   docs/{name} 已存在")
        return True

    source = TEMPLATE_DIR / name
    if not source.exists():
        report.append(f"[FAIL] docs/{name} 缺失，且模板 templates/{name} 不存在")
        return False

    target.parent.mkdir(parents=True, exist_ok=True)
    # 从模板生成时替换 {DATE} 占位符，避免建档后残留字面量
    content = source.read_text(encoding="utf-8").replace("{DATE}", TODAY_STAMP)
    target.write_text(content, encoding="utf-8")
    report.append(f"[NEW]  已从模板创建 docs/{name}")
    return True


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="工作守则建档与校验")
    parser.add_argument("--root", help="工作空间根目录（默认自动探测）")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出报告")
    args = parser.parse_args(argv)

    root = resolve_root(args.root)
    docs_dir = root / "docs"
    report: list[str] = []
    problems: list[str] = []

    if not (root / MARKER).exists():
        report.append(f"[WARN] 未在 {root} 找到 {MARKER}，请确认根目录是否正确")

    for name in DOC_NAMES:
        if not ensure_doc(root, name, report):
            problems.append(f"docs/{name} 无法创建")

    progress = docs_dir / "当前进度.md"
    if progress.exists():
        if progress_is_fresh(progress):
            report.append(f"[OK]   docs/当前进度.md 已于今日（{TODAY_STAMP}）更新")
        else:
            msg = f"docs/当前进度.md 未在今日（{TODAY_STAMP}）更新，须先回写进度"
            report.append(f"[WARN] {msg}")
            problems.append(msg)

    if args.json:
        print(
            __import__("json").dumps(
                {
                    "root": str(root),
                    "date": TODAY_STAMP,
                    "ready": not problems,
                    "report": report,
                    "problems": problems,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        print(f"工作空间根目录: {root}")
        print(f"建档校验日期  : {TODAY_STAMP}")
        print("-" * 52)
        for line in report:
            print(line)
        print("-" * 52)
        if problems:
            print("结论: 需处理（退出码 1）")
            for item in problems:
                print(f"  - {item}")
        else:
            print("结论: 三文档就绪（退出码 0）")

    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
