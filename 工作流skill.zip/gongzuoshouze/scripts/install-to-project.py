#!/usr/bin/env python3
"""install-to-project.py — 把「工作守则」skill 安装到指定项目文件夹。

背景（双轨制）：
    skill 的生效安装只能位于用户级目录（~/.workbuddy-ai/skills/），项目级
    <项目>/.workbuddy-ai/skills/ 不被系统扫描。因此：
      - 用户级副本负责生效，description 白名单登记所有已授权工作空间；
      - 项目级副本随项目自包含管理，供版本控制与离线重建。

用法：
    python install-to-project.py <项目路径> [--source <skill源目录>] [--rules <工作守则.md路径>]

动作：
    1. 复制 skill 全部文件到 <项目>/.workbuddy-ai/skills/gongzuoshouze/；
    2. 若 <项目>/工作守则.md 不存在，从源工作空间复制（bootstrap 的标记文件）；
    3. 强制创建 <项目>/backups/ 与 <项目>/docs/（幂等：缺失才建，绝不覆盖）；
    4. 确保项目副本 scripts/bootstrap.py 的 DEFAULT_WORKSPACE 指向 <项目>；
    5. 把项目副本 SKILL.md 的 description 白名单收窄为仅 <项目>；
    6. 幂等地把 <项目> 追加进用户级副本 SKILL.md 的白名单。

--rules 用途：从用户级副本运行时，无法按相对位置推断源工作空间，
需显式给出《工作守则.md》路径（仅当目标项目尚无该文件时才需要）。

退出码：0 = 成功；1 = 失败（目标不存在 / 源无效 / 缺标记文件且未提供 --rules）。
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_SKILL_DIR = SCRIPT_DIR.parent                    # <源>/gongzuoshouze
DEFAULT_SOURCE_WORKSPACE = DEFAULT_SKILL_DIR.parents[2]  # skill 目录上三级 = 源工作空间
RULES_FILE = "工作守则.md"
USER_SKILL_DIR = Path.home() / ".workbuddy-ai" / "skills" / "gongzuoshouze"
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo")


def replace_workspace_paths(text: str, old: Path, new: Path) -> str:
    """把文本中源工作空间路径（反斜杠与正斜杠两种写法）替换为新路径。

    新路径统一为正斜杠写法，与 SKILL.md description 的既有风格一致
    （bootstrap.py 代码内的路径不走这里，保持 Path(r"...") 原样）。
    """
    out = text
    new_fwd = str(new).replace("\\", "/")
    for variant in {str(old), str(old).replace("\\", "/")}:
        out = out.replace(variant, new_fwd)
    return out


def update_user_whitelist(target: Path) -> str:
    """把 target 幂等追加进用户级副本 SKILL.md 的 description 白名单。"""
    skill_md = USER_SKILL_DIR / "SKILL.md"
    if not skill_md.exists():
        return "WARN: 用户级副本不存在（%s），跳过白名单登记" % USER_SKILL_DIR
    text = skill_md.read_text(encoding="utf-8")
    t = str(target).replace("\\", "/")
    # 括号用字符类同时兼容全角"）"与半角")"，避免定位失败
    m = re.search(r"仅适用于(?:以下)?工作空间[：:]?\s*([^）)]*)[）)]", text)
    paths = [p.strip() for p in re.split(r"[、,，]", m.group(1)) if p.strip()] if m else []
    if t in paths:
        return "OK: 用户级白名单已包含 %s（无需改动）" % t
    if not m:
        return "WARN: 未能在用户级 SKILL.md 中定位白名单片段，请手工添加 %s" % t
    paths.append(t)
    new_seg = "仅适用于以下工作空间：" + "、".join(paths) + "）"
    text = text[: m.start()] + new_seg + text[m.end():]
    text = text.replace("只服务于上述这一个工作空间", "只服务于上述工作空间")
    skill_md.write_text(text, encoding="utf-8")
    return "OK: 用户级白名单已追加 %s（现有 %d 个工作空间）" % (t, len(paths))


def ensure_default_workspace(boot: Path, target: Path) -> None:
    """确保项目副本的 bootstrap.py 中 DEFAULT_WORKSPACE 指向 target。

    改写优先；若源码是用户级简化版（无该常量），则在 MARKER 定义后注入。
    全部替换经函数式回填，避免路径反斜杠被正则当作转义。
    """
    text = boot.read_text(encoding="utf-8")
    pattern = re.compile(r'DEFAULT_WORKSPACE = Path\(r"[^"]*"\)')
    if pattern.search(text):
        new_text = pattern.sub(lambda m: 'DEFAULT_WORKSPACE = Path(r"%s")' % target, text)
        boot.write_text(new_text, encoding="utf-8")
        print("[OK]   项目副本 DEFAULT_WORKSPACE -> %s" % target)
        return
    marker_pat = re.compile(r'(MARKER = "工作守则\.md"\n)')
    inject = (
        "\n# 本项目副本的唯一服务对象（优先级最低，可被 --root 与 cwd 覆盖）。\n"
        'DEFAULT_WORKSPACE = Path(r"%s")\n' % target
    )
    if marker_pat.search(text):
        new_text = marker_pat.sub(lambda m: m.group(1) + inject, text, count=1)
        boot.write_text(new_text, encoding="utf-8")
        print("[OK]   项目副本已注入 DEFAULT_WORKSPACE -> %s" % target)
        return
    print("[WARN] 项目副本中未找到 DEFAULT_WORKSPACE 定义，也未找到注入点，请人工检查")


def ensure_workspace_dirs(target: Path) -> list[str]:
    """强制创建 backups/ 与 docs/（幂等：缺失才建，绝不覆盖、绝不删除）。

    backups/ 为稳定版归档目录（守则 4.2）；docs/ 为三文档目录（守则第一章）。
    docs/ 平时由 bootstrap.py 生成三文档时隐式创建，此处提前建好骨架，
    使安装完成即具备完整工作空间结构。
    """
    results = []
    for dirname in ("backups", "docs"):
        d = target / dirname
        if d.is_dir():
            results.append("[SKIP] %s/ 已存在，未改动" % dirname)
        elif d.exists():
            results.append("[WARN] %s 存在但不是目录，请人工检查：%s" % (dirname, d))
        else:
            d.mkdir(parents=True)
            results.append("[OK]   已创建 %s/" % dirname)
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="把工作守则 skill 安装到指定项目文件夹")
    parser.add_argument("project", help="目标项目文件夹路径（必须已存在）")
    parser.add_argument("--source", help="skill 源目录（默认取本脚本所在 skill 目录）")
    parser.add_argument("--rules", help="《工作守则.md》源路径（默认取 skill 源目录上三级的工作空间）")
    args = parser.parse_args(argv)

    target = Path(args.project).expanduser().resolve()
    if not target.is_dir():
        print("[FAIL] 目标项目不存在：%s" % target, file=sys.stderr)
        return 1

    skill_src = Path(args.source).resolve() if args.source else DEFAULT_SKILL_DIR
    if not (skill_src / "SKILL.md").exists():
        print("[FAIL] skill 源目录无效：%s" % skill_src, file=sys.stderr)
        return 1

    source_workspace = skill_src.parents[2]
    if args.rules:
        rules_src = Path(args.rules).expanduser().resolve()
    else:
        rules_src = source_workspace / RULES_FILE

    # 1) 复制 skill 全文件到项目
    skill_dst = target / ".workbuddy-ai" / "skills" / "gongzuoshouze"
    shutil.copytree(skill_src, skill_dst, ignore=IGNORE, dirs_exist_ok=True)
    print("[OK]   已复制 skill 到 %s" % skill_dst)

    # 2) 补放守则标记文件（不覆盖既有；都没有时明确失败）
    rules_dst = target / RULES_FILE
    if rules_dst.exists():
        print("[SKIP] %s 已存在，未覆盖" % rules_dst)
    elif rules_src.exists():
        shutil.copyfile(rules_src, rules_dst)
        print("[OK]   已复制 %s 到项目根目录（标记文件）" % RULES_FILE)
    else:
        print(
            "[FAIL] 找不到《工作守则.md》源：%s 不存在，且目标项目也无该文件。\n"
            "       请用 --rules <工作守则.md 路径> 显式指定。" % rules_src,
            file=sys.stderr,
        )
        return 1

    # 3) 强制创建 backups/ 与 docs/（幂等：缺失才建，绝不覆盖）
    for line in ensure_workspace_dirs(target):
        print(line)

    # 4) 确保项目副本 DEFAULT_WORKSPACE 指向本项目
    ensure_default_workspace(skill_dst / "scripts" / "bootstrap.py", target)

    # 5) 收窄项目副本 SKILL.md 白名单为仅本项目（先换路径，再折叠多工作空间写法）
    skill_md = skill_dst / "SKILL.md"
    text = skill_md.read_text(encoding="utf-8")
    new_text = replace_workspace_paths(text, source_workspace, target)
    m = re.search(r"仅适用于以下工作空间：[^）)]*[）)]", new_text)
    if m:
        seg = "仅适用于工作空间 %s）" % str(target).replace("\\", "/")
        new_text = new_text[: m.start()] + seg + new_text[m.end():]
    if new_text != text:
        skill_md.write_text(new_text, encoding="utf-8")
        print("[OK]   项目副本 description 白名单已收窄为 %s" % target)
    else:
        print("[WARN] 项目副本 description 未发生变化，请人工检查")

    # 6) 幂等登记用户级白名单
    print(update_user_whitelist(target))

    print("-" * 52)
    print("安装完成。后续两步：")
    print("  1) 在项目内建档：cd %s && python %s" % (target, skill_dst / "scripts" / "bootstrap.py"))
    print("  2) 新开一个会话，本 skill 才会在该项目内被触发（清单在会话启动时载入）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
